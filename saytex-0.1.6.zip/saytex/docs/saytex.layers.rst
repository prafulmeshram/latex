saytex.layers package
=====================

Submodules
----------

saytex.layers.capitalization module
-----------------------------------

.. automodule:: saytex.layers.capitalization
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.case\_insensitivity module
----------------------------------------

.. automodule:: saytex.layers.case_insensitivity
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.divided\_by\_recognition module
---------------------------------------------

.. automodule:: saytex.layers.divided_by_recognition
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.from\_to\_recognition module
------------------------------------------

.. automodule:: saytex.layers.from_to_recognition
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.handle\_of module
-------------------------------

.. automodule:: saytex.layers.handle_of
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.layer module
--------------------------

.. automodule:: saytex.layers.layer
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.math\_symbols\_transform module
---------------------------------------------

.. automodule:: saytex.layers.math_symbols_transform
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.prettification module
-----------------------------------

.. automodule:: saytex.layers.prettification
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.speech\_recognition\_error\_correction module
-----------------------------------------------------------

.. automodule:: saytex.layers.speech_recognition_error_correction
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.spoken\_number\_recognition module
------------------------------------------------

.. automodule:: saytex.layers.spoken_number_recognition
    :members:
    :undoc-members:
    :show-inheritance:

saytex.layers.synonym\_standardization module
---------------------------------------------

.. automodule:: saytex.layers.synonym_standardization
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: saytex.layers
    :members:
    :undoc-members:
    :show-inheritance:
