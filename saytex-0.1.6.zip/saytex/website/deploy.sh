#!/usr/bin/env bash
git subtree push --prefix website origin gh-pages
